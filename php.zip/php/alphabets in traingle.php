    <?php  
    for( $i=65; $i<=69; $i++){   
       for($j=5; $j>=$i-64; $j--){  
        echo chr($i);  
        }  
        echo "<br>";  
    }  
    ?>  
